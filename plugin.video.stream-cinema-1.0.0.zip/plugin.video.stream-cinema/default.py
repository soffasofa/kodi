import xbmcgui
xbmcgui.Dialog().ok("Stream Cinema", "Doplnok funguje zo zálohy!")